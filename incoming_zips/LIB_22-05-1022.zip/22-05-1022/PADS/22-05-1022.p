*PADS-LIBRARY-PART-TYPES-V9*

22-05-1022 SHDRRA2W64P0X250_1X2_450X1330X670P I CON 7 1 0 0 0
TIMESTAMP 2025.05.13.07.26.58
"Mouser Part Number" 538-22-05-1022
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/22-05-1022?qs=53in8j6h7oR291AEgcCURA%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 22-05-1022
"Description" MOLEX - 22-05-1022 - Pin Header, Right Angle, Wire-to-Board, 2.5 mm, 1 Rows, 2 Contacts, Through Hole Right Angle
"Datasheet Link" https://www.molex.com/pdm_docs/sd/022051022_sd.pdf
"Geometry.Height" 6.7mm
GATE 1 2 0
22-05-1022
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
13491951/412425/2.50/2/3/Connector
